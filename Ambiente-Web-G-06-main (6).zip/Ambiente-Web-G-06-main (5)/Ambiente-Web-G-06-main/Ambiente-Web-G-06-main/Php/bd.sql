-- Crear la base de datos
CREATE DATABASE IF NOT EXISTS tienda;

USE tienda;

-- Crear la tabla de productos
CREATE TABLE IF NOT EXISTS productos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    precio DECIMAL(10, 2) NOT NULL,
    descripcion TEXT,
    imagen VARCHAR(255)
);

-- Crear la tabla de usuarios (si aún no tienes una tabla de usuarios, puedes agregarla)
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    contrasena VARCHAR(255) NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Crear la tabla del carrito de compras (solo para guardar productos en sesión si fuera necesario)
CREATE TABLE IF NOT EXISTS carrito (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT,
    producto_id INT,
    cantidad INT DEFAULT 1,
    total DECIMAL(10, 2) NOT NULL,
    fecha_agregado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY (producto_id) REFERENCES productos(id)
);

-- Agregar algunos productos para pruebas (puedes agregar más productos según necesites)
INSERT INTO productos (nombre, precio, descripcion, imagen) VALUES
('Producto 1', 10.00, 'Descripción del producto 1', 'producto1.jpg'),
('Producto 2', 20.00, 'Descripción del producto 2', 'producto2.jpg'),
('Producto 3', 30.00, 'Descripción del producto 3', 'producto3.jpg');

-- Agregar algunos usuarios para pruebas (si no tienes sistema de login aún)
INSERT INTO usuarios (nombre, email, contrasena) VALUES
('Juan Pérez', 'juan@example.com', 'password123'),
('Ana López', 'ana@example.com', 'password456');
