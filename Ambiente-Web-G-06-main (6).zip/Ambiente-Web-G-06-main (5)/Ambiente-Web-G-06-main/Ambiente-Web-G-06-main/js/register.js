const usuarios = [{ email: "br2323yan12@gmail.com", password: "p123" }];

document.addEventListener("DOMContentLoaded", function () {
  const registerForm = document.getElementById("register-form");
  const registerError = document.getElementById("register-error");

  registerForm.addEventListener("submit", function (e) {
    e.preventDefault();

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm-password").value;
    const errormsg = "Password and confirmation don't match";

    if (password !== confirmPassword) {
      registerError.innerHTML = `<div class="alert alert-danger fade show" role="alert">
            <strong>Error:</strong> ${errormsg}
            </div>`;
      return;
    } else {
      const usuario = {
        email: email,
        password: password,
      };
      usuarios.push(usuario);
      arrayJsonStorage();

      registerError.innerHTML = `<div class="alert alert-success fade show" role="alert">
            <strong>Success:</strong> Email: ${email} successfully registered.
            </div>`;
      setTimeout(function () {
        registerError.innerHTML = "";
        window.location.href = "login.html";
      }, 5000);
    }
  });
});

function arrayJsonStorage() {
  localStorage.setItem("credenciales", JSON.stringify(usuarios));
}
