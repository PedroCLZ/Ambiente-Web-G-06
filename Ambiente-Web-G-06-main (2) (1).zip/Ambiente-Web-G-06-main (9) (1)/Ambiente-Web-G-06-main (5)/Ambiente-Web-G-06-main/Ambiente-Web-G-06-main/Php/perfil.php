<?php
session_start();
include('db.php');

// Verifica si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html'); // Redirige al login si no hay sesión activa
    exit();
}

$user_id = $_SESSION['user_id']; // Suponemos que el ID de usuario está almacenado en la sesión

// Consulta para obtener los datos del usuario
$query = "SELECT nombre, email, telefono FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id); // "i" significa que esperamos un entero (ID de usuario)
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Obtener los datos del usuario
    $user = $result->fetch_assoc();
} else {
    echo "No se encontraron datos para este usuario.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
    <title>Perfil</title>
  </head>
  <body class="bg-dark">
    <style>
      a, p {
        color: white;
      }
    </style>

    <header class="d-flex align-items-center justify-content-between p-3 m-auto" style="width: 85%;">
      <div class="logo">
        <a href="inicio.html"><i class="fa-solid fa-mug-hot fa-2x"></i></a>
      </div>
      <nav class="text-light">
        <ul class="nav">
          <li class="nav-item">
            <a href="inicio.html" class="nav-link active" aria-current="page">Inicio</a>
          </li>
          <li class="nav-item">
            <a href="menu.html" class="nav-link">Menú</a>
          </li>
          <li class="nav-item">
            <a href="bebidas.html" class="nav-link">Bebidas</a>
          </li>
          <li class="nav-item">
            <a href="contactenos.html" class="nav-link">Contacto</a>
          </li>
          <li class="nav-item">
            <a href="reposteria.html" class="nav-link">Repostería</a>
          </li>
          <li class="nav-item">
            <a href="cateringCorporativo.html" class="nav-link">Catering Corporativo</a>
          </li>
          <li class="nav-item">
            <a href="perfil.html" class="nav-link perfil">Perfil</a>
          </li>
          <li class="nav-item">
            <a href="carrito.html" class="nav-link">
              <i class="fa-solid fa-cart-shopping"></i>
            </a>
          </li>
          <li class="nav-item">
            <a href="login.html" class="nav-link">Login</a>
          </li>
          <li class="nav-item">
            <a href="register.html" class="nav-link">Register</a>
          </li>
        </ul>
      </nav>
    </header>
    
    <div class="logo d-flex justify-content-center mb-4 mt-4">
      <img src="images/principal.png" style="border-radius: 150px; width: 200px; height: 200px;">
    </div>

    <div class="container d-flex justify-content-center align-items-center">
      <div class="col-lg-6">
        <div class="card mb-4 bg-dark border-0">
          <div class="card-body">
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0" id="name">Full Name</p>
              </div>
              <div class="col-sm-9">
                <p class="text-warning mb-0"><?php echo htmlspecialchars($user['nombre']); ?></p>
              </div>
            </div>
            <hr />
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Email</p>
              </div>
              <div class="col-sm-9">
                <p class="text-warning mb-0"><?php echo htmlspecialchars($user['email']); ?></p>
              </div>
            </div>
            <hr />
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0" id="phone">Phone</p>
              </div>
              <div class="col-sm-9">
                <p class="text-warning mb-0"><?php echo htmlspecialchars($user['telefono']); ?></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
