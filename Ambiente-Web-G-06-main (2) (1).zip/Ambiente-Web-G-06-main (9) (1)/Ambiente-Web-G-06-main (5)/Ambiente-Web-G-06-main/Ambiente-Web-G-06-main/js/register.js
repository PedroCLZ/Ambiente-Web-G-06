document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("register-form");
  const registerError = document.getElementById("register-error");

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm-password").value;

    if (password !== confirmPassword) {
      registerError.textContent = "Passwords do not match!";
      registerError.style.display = "block";
      return;
    }

    const userData = {
      email,
      password
    };

    fetch('register.php', {
      method: 'POST',
      body: new URLSearchParams(userData),
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        window.location.href = 'login.html';  // Redirect to login page after successful registration
      } else {
        registerError.textContent = data.message;
        registerError.style.display = "block";
      }
    })
    .catch(error => {
      registerError.textContent = "An error occurred. Please try again.";
      registerError.style.display = "block";
    });
  });
});
