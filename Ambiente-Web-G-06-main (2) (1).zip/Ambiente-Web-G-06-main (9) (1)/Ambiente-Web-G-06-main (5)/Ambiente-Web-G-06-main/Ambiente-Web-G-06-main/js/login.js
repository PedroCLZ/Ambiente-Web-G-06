document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("login-form");
  const loginError = document.getElementById("login-error");

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    // Realizar la solicitud AJAX
    fetch('login.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: `email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`
    })
    .then(response => response.json()) // Asumimos que el servidor devuelve un JSON
    .then(data => {
      if (data.success) {
        window.location.href = "inicio.html"; // Redirigir al inicio si el login es exitoso
      } else {
        // Mostrar un mensaje de error si el login falla
        loginError.style.display = "block";
        loginError.textContent = data.message;
      }
    })
    .catch(error => {
      console.error('Error:', error);
      loginError.style.display = "block";
      loginError.textContent = "Ocurrió un error, por favor intente nuevamente.";
    });
  });
});

