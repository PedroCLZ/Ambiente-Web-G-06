document.addEventListener("DOMContentLoaded", function () {
  // Obtener los datos del usuario directamente desde el HTML, que están insertados por PHP
  const email = document.getElementById("email");
  const name = document.getElementById("name");
  const phone = document.getElementById("phone");

  // Asignar los valores de los datos del usuario desde PHP a los elementos HTML
  email.textContent = "<?php echo htmlspecialchars($user['email']); ?>";
  name.textContent = "<?php echo htmlspecialchars($user['nombre']); ?>";
  phone.textContent = "<?php echo htmlspecialchars($user['telefono']); ?>";
});

